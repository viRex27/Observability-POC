exports.handler = async (event) => {
    // logging business observability logs
    console.log(JSON.stringify(event));
    // console.log("momentIdentifier: "+ event.detail.momentIdentifier + "/n"+ "message: "+event.detail.message);
}