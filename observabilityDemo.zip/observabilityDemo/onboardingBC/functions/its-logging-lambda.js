//  Lambda to emit business relevant logging event to Data Sink BC

const AWS = require('aws-sdk')

exports.handler = async (event) => {
    console.log(JSON.stringify(event));

    var currentdate = new Date(); 
    var datetime = currentdate.getDate() + "/"
                + (currentdate.getMonth()+1)  + "/" 
                + currentdate.getFullYear() + " @ "  
                + currentdate.getHours() + ":"  
                + currentdate.getMinutes() + ":" 
                + currentdate.getSeconds();
                console.log(datetime);
    // creating payload for event to be sent to event bus
    const addedEvent = {
        "traceId": event.Payload.payload.traceId,
        "message": event.Payload.message,
        "momentIdentifier": event.Payload.momentIdentifier,
        "emittedAt": datetime,

    }
    console.log(addedEvent);
    
    const eventbridge = new AWS.EventBridge();
    const params = {
        Entries: [ 
            {
              Detail: JSON.stringify(addedEvent),
              DetailType: 'business-event-log',
              EventBusName: 'ItsOnBoardingContextEventBus',
              Source: event.Payload.source,
            },
          ]
      }

    // Putting event to Onboardng Context event bus
      const result = await eventbridge.putEvents(params).promise()
      console.log(JSON.stringify(params));
      console.log(result);

}