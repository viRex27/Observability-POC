const {v4: uuid} = require('uuid');
exports.handler = async () => uuid();