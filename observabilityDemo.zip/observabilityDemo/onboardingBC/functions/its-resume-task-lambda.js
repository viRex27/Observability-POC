// This lambda will be invoked when we receive any event back from second bounded context(Benefts BC or Reviewer BC) to first bounded context (Onboarding BC)
// This will consume event from Onboardng Context Event Bus and then from the payload it will get traceId and delegationid and then using them it will find taskToken from DynamoDB
// Then on the basis of that it will dend taskSuccess/ taskFailure call to the stepfunction to resume and proceed further.

const AWS = require('aws-sdk')
const documentClient = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    console.log(JSON.stringify(event));
    
    console.log("traceId: " + event.detail.payload.traceId);
    console.log("delegationId: "+ event.detail.delegationId);
    const delegationid = event.detail.delegationId

    const par = {
        TableName: process.env.DatabaseTable,
        Key: {
           "id": event.detail.payload.traceId
        }
    }
    // searching for the entry in the DynamoDB table with traceId and storing it in the record.
    const result = await documentClient.get(par).promise();
    console.log(JSON.stringify(result));                     

    const TaskToken = result.Item.delegations[delegationid].task.taskToken;      // taskToken
    console.log(TaskToken);

    var stepfunctions = new AWS.StepFunctions();
    
     // Creating payload for taskSuccess/ taskFailure call
     const params = {
        output: JSON.stringify(event.detail.payload),
        taskToken: TaskToken,
    }
    // const para = {
    //     cause: "Some Random Error",
    //     error: "RandomErrorException",
    //     taskToken: TaskToken
    // }
    
    // const min = 1
    // const max = 4
    // const num = Math.floor(min + Math.random()*(max - min + 1))
    // if( num > 2){
    const response = await stepfunctions.sendTaskSuccess(params).promise();       // taskSuccess call
    console.log(response);
    // }
    // else{
    // const res = await stepfunctions.sendTaskFailure(para).promise();        // taskFailure call
    // console.log(res);
    // }
}